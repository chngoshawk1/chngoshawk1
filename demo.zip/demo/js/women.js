function tankuang(){
    $('.motai').fadeIn();
}
function shuttan(){
    $('.motai').fadeOut();
}
$(function(){
    $(document).scroll(function(){
        var cTop = $(this).scrollTop()+$(window).innerHeight();
        if(cTop>$('.often').offset().top){
            $('.often').addClass('animated fadeInLeft');
        }
    });
    $('.tankuang').click(function(){
        tankuang();
    })
    $('.boda').click(function(){
        shuttan();
    })
    $('.motai').click(function(ev){
        shuttan()
    })
    $('.mo-inner').click(function(ev){
        ev.stopPropagation();
    })
})