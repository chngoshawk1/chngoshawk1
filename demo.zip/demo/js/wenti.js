function tankuang(){
    $('.motai').fadeIn();
}
function shuttan(){
    $('.motai').fadeOut();
}
$(function(){
    $(document).scroll(function(){
        var cTop = $(this).scrollTop()+$(window).innerHeight();
        if(cTop>$('.often').offset().top){
            $('.often').addClass('animated fadeInLeft');
        }
        if(cTop>$('.chengxin').offset().top){
            $('.chengxin').addClass('animated fadeInUp');
        }
        if(cTop>$('.chengList').offset().top){
            $('.chengList').addClass('animated fadeInUp');
        }
    });
    $('.tankuang').click(function(){
        tankuang();
    })
    $('.boda').click(function(){
        shuttan();
    })
    $('.motai').click(function(ev){
        shuttan()
    })
    $('.mo-inner').click(function(ev){
        ev.stopPropagation();
    })

    $('.items li').click(function(){
        $('.items li').removeClass('chooseCol');
        $(this).addClass('chooseCol');
    });
    $('.itemList li').click(function(){
        $('.itemList li').removeClass('active');
        $(this).addClass('active');
        $('.questions').css({
            display: 'none',
        })
        $('.questions').eq($(this).index()).css({
            display: 'block',
        })
    });
})