function tankuang(){
    $('.motai').fadeIn();
}
function shuttan(){
    $('.motai').fadeOut();
}
$(function(){
    $(document).scroll(function(){
        var cTop = $(this).scrollTop()+$(window).innerHeight()-100;
        if(cTop>$('.often').offset().top){
            $('.often').addClass('animated fadeInLeft');
        }
        if(cTop>$('.progdetail').offset().top){
            $('.progdetail').addClass('animated fadeInUp');
        }
        if(cTop>$('.regImg').offset().top){
            $('.regImg').addClass('animated fadeInUp');
        }
        if(cTop>$('.ziliao').offset().top){
            $('.ziliao').addClass('animated fadeInUp');
        }
        if(cTop>$('.ziliaoList').offset().top){
            $('.ziliaoList').addClass('animated fadeInUp');
        }
        if(cTop>$('.banli').offset().top){
            $('.banli').addClass('animated fadeInUp');
        }
        if(cTop>$('.banImg').offset().top){
            $('.banImg').addClass('animated fadeInUp');
        }
        if(cTop>$('.chengxin').offset().top){
            $('.chengxin').addClass('animated fadeInUp');
        }
        if(cTop>$('.chengList').offset().top){
            $('.chengList').addClass('animated fadeInUp');
        }
    });
    $('.tankuang').click(function(){
        tankuang();
    })
    $('.boda').click(function(){
        shuttan();
    })
    $('.motai').click(function(ev){
        shuttan()
    })
    $('.mo-inner').click(function(ev){
        ev.stopPropagation();
    })

    $('.items li').click(function(){
        $('.items li').removeClass('chooseCol');
        $(this).addClass('chooseCol');
    });
})