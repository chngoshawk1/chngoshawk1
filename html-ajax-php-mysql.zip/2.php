<?php

$con = mysql_connect("localhost","root","root");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("user_phone", $con);
mysql_query("set names 'utf8'");
$result = mysql_query("SELECT * FROM user_phone_test");
// $row = mysql_fetch_array($result,MYSQL_ASSOC );
// $row=json_encode($row);

//  var_dump($row);
// die();
$results="";
while($row = mysql_fetch_array($result,MYSQL_ASSOC))
  { 
    if($results != ""){
        $results.=",";
    }
    $results.='{"user":"'.$row["user"].'",';
    $results.='"phone":"'.$row["phone"].'",';
    $results.='"c_date":"'.$row["c_date"].'"}';
  }
$results='['.$results.']';
mysql_close($con);
echo $results;

//SELECT * FROM biao1 WHERE (user='zou' and pass='123456') or path is not NULL ORDER BY user desc

?>

