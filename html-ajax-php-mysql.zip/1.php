<?php

$con = mysql_connect("localhost","root","root");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
  else
	  echo "ok</br>";
  

$user=$_GET['user'];
$phone=$_GET['phone'];
date_default_timezone_set("Asia/Shanghai");
$wtime=date("Y-m-d H:i:s");
// echo $user."</br>".$phone;
// die();
  
mysql_select_db("user_phone", $con);e
mysql_query("set names 'utf8'");
//INSERT INTO user_phone_test (user,phone,f_date,l_date) VALUES ('a', 'b','2018/01/01 1:1:1','2018/01/01 1:1:1')
$res = mysql_query("INSERT INTO user_phone_test (user,phone,c_date) VALUES ('$user', '$phone','$wtime')");
if ($res) echo "ins ok";
mysql_close($con);


// mysql_select_db("tab1", $con);
// mysql_query("set names 'utf8'");
// $result = mysql_query("SELECT count(*) as num FROM biao1 where user='zou4'");
// $row = mysql_fetch_array($result,MYSQL_ASSOC );
// $row=json_encode($row);
//  var_dump($row);
// // die();
// while($row = mysql_fetch_array($result,MYSQL_ASSOC))
//   { 
// 	//$row=json_encode($row);
// 	//var_dump($row);
//   echo $row['user'] . " " . $row['pass'];
//   echo "<br />";
//   }

// mysql_close($con);

//SELECT * FROM biao1 WHERE (user='zou' and pass='123456') or path is not NULL ORDER BY user desc

?>

